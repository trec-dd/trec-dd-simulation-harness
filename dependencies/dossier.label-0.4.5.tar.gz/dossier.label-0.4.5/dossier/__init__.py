'''dossier.* namespace package has several subpackages, see
http://github.com/dossier for more info

.. This software is released under an MIT/X11 open source license.
   Copyright 2012-2014 Diffeo, Inc.

'''
import pkg_resources
pkg_resources.declare_namespace(__name__)
